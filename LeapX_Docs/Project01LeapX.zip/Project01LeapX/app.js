/**
 * GymHub Dashboard — Settings Section
 * app.js | Vanilla JS, no dependencies
 *
 * BUGS FIXED:
 *  1. Accordion body never collapsed — JS toggled aria but no CSS existed to
 *     actually hide/show the body. CSS is now fixed; JS correctly toggles aria.
 *  2. Accordion chevron never rotated — CSS now rotates on aria-expanded="true".
 *  3. Toast was always visible — toast--visible was never defined in CSS (now fixed).
 *     JS logic was correct; CSS was the issue. toast also had no default hidden state.
 *  4. Dark mode toggle: applyTheme called before DOM ready on initial load was fine,
 *     but localStorage key could clash. Namespaced properly.
 *  5. initIcons called once at boot but Lucide icons injected into accordion body
 *     (hidden section) render correctly since lucide scans all data-lucide attrs.
 *     Re-run createIcons after accordion first opens to ensure SVGs render.
 *  6. Hamburger mobile menu toggle added (was in HTML but no JS handler existed).
 *  7. Save button: btn--loading state now correctly works with the CSS-defined
 *     .btn--loading .btn__text { display:none } and .btn__spinner { display:flex }.
 *  8. Event delegation added for robustness.
 */

'use strict';

/* ══════════════════════════════════════════
   UTILITY
══════════════════════════════════════════ */

const wait = (ms) => new Promise((res) => setTimeout(res, ms));

/* ══════════════════════════════════════════
   1. LUCIDE ICONS
══════════════════════════════════════════ */

function initIcons() {
  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    window.lucide.createIcons();
  }
}

/* ══════════════════════════════════════════
   2. ACCORDION — Profile Information
   FIX: accordion body visibility is controlled by CSS (max-height transition).
   JS only needs to toggle the aria-expanded attribute on both the wrapper
   and the trigger button. The CSS does the rest.
   FIX: Re-run initIcons after first open so Lucide SVGs inside the
   accordion body (which was hidden on page load) render correctly.
══════════════════════════════════════════ */

function initAccordion() {
  const accordion = document.getElementById('accordion-profile');
  const trigger   = document.getElementById('accordion-profile-trigger');

  if (!accordion || !trigger) return;

  let iconsRenderedInBody = false;

  trigger.addEventListener('click', () => {
    const isExpanded = accordion.getAttribute('aria-expanded') === 'true';
    const nextState  = !isExpanded;

    // Toggle aria on both wrapper (controls CSS) and button (for AT)
    accordion.setAttribute('aria-expanded', String(nextState));
    trigger.setAttribute('aria-expanded',   String(nextState));

    // FIX: Re-run createIcons the first time the accordion opens,
    // because Lucide may not have rendered SVGs inside hidden content.
    if (nextState && !iconsRenderedInBody) {
      iconsRenderedInBody = true;
      initIcons();
    }
  });
  // Keyboard: Space / Enter already fires click on <button> — no extra handling needed
}

/* ══════════════════════════════════════════
   3. SAVE BUTTON — loading state + toast
   FIX: CSS now defines btn--loading, btn__text visibility, btn__spinner display.
   The JS logic here was always correct; the CSS was missing.
══════════════════════════════════════════ */

function initSaveButton() {
  const btn   = document.getElementById('save-btn');
  const toast = document.getElementById('toast');

  if (!btn || !toast) return;

  btn.addEventListener('click', async () => {
    // Debounce: ignore clicks while already loading
    if (btn.classList.contains('btn--loading')) return;

    // --- Enter loading state ---
    btn.classList.add('btn--loading');
    btn.setAttribute('aria-label', 'Saving, please wait…');

    await wait(1500);

    // --- Leave loading state ---
    btn.classList.remove('btn--loading');
    btn.setAttribute('aria-label', 'Save Changes');

    // --- Show toast ---
    showToast(toast);
  });
}

function showToast(toastEl) {
  // FIX: toast--visible is now defined in CSS; this adds/removes it.
  // The CSS transitions handle the animation (translateY + opacity).
  toastEl.classList.add('toast--visible');

  setTimeout(() => {
    toastEl.classList.remove('toast--visible');
  }, 3000);
}

/* ══════════════════════════════════════════
   4. DARK / LIGHT MODE TOGGLE
   FIX: applyTheme is called synchronously on load (before any paint)
   to avoid flash of incorrect theme.
══════════════════════════════════════════ */

function initDarkModeToggle() {
  const toggle = document.getElementById('toggle-dark');
  if (!toggle) return;

  // Read persisted preference and apply immediately
  const stored = localStorage.getItem('gymhub-theme');
  if (stored) {
    applyTheme(stored, toggle);
  }
  // If no stored value, the HTML data-theme="dark" default stands.

  toggle.addEventListener('change', () => {
    const theme = toggle.checked ? 'dark' : 'light';
    applyTheme(theme, toggle);
    localStorage.setItem('gymhub-theme', theme);
  });
}

function applyTheme(theme, toggleEl) {
  document.documentElement.setAttribute('data-theme', theme);
  if (toggleEl) {
    toggleEl.checked = (theme === 'dark');
  }
}

/* ══════════════════════════════════════════
   5. NOTIFICATION TOGGLES
══════════════════════════════════════════ */

function initNotificationToggles() {
  const toggleMap = {
    'toggle-push':      'Push Notifications',
    'toggle-email':     'Email Updates',
    'toggle-marketing': 'Marketing Emails',
  };

  Object.entries(toggleMap).forEach(([id, label]) => {
    const el = document.getElementById(id);
    if (!el) return;

    el.addEventListener('change', () => {
      console.log(`[GymHub] ${label}: ${el.checked ? 'enabled' : 'disabled'}`);
      // Wire to your API here, e.g.: updateNotificationPreference(id, el.checked)
    });
  });
}

/* ══════════════════════════════════════════
   6. MOBILE HAMBURGER MENU
   FIX: hamburger button existed in HTML but had NO JS handler at all.
══════════════════════════════════════════ */

function initHamburger() {
  const btn = document.getElementById('hamburger-btn');
  const nav = document.getElementById('mobile-nav');

  if (!btn || !nav) return;

  btn.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('is-open');
    btn.setAttribute('aria-expanded', String(isOpen));
    // Swap icon between menu and X
    btn.innerHTML = isOpen
      ? '<i data-lucide="x"></i>'
      : '<i data-lucide="menu"></i>';
    initIcons(); // Re-render the swapped icon
  });

  // Close nav when a link inside is clicked
  nav.addEventListener('click', (e) => {
    if (e.target.closest('.nav-link')) {
      nav.classList.remove('is-open');
      btn.setAttribute('aria-expanded', 'false');
      btn.innerHTML = '<i data-lucide="menu"></i>';
      initIcons();
    }
  });

  // Close nav when clicking outside
  document.addEventListener('click', (e) => {
    if (!btn.contains(e.target) && !nav.contains(e.target)) {
      nav.classList.remove('is-open');
      btn.setAttribute('aria-expanded', 'false');
      btn.innerHTML = '<i data-lucide="menu"></i>';
      initIcons();
    }
  });
}

/* ══════════════════════════════════════════
   BOOT
══════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {
  initIcons();
  initAccordion();
  initSaveButton();
  initDarkModeToggle();
  initNotificationToggles();
  initHamburger();
});
